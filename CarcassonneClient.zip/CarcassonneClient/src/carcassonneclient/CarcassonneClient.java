package carcassonneclient;

import controller.Controller;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URISyntaxException;
import java.rmi.RemoteException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.stage.Screen;

public class CarcassonneClient extends Application {
        
    private Scene scene;
    
    @Override
    public void start(Stage primaryStage) throws URISyntaxException, RemoteException, IOException {
        
        Group group = new Group();
        scene = new Scene(group, 1154, 768); //átírni majd
        scene.getStylesheets().add(this.getClass().getResource("/resources/css/style.css").toExternalForm());
        //Controller controller = new Controller(scene);
        scene.setRoot(FXMLLoader.load(getClass().getClassLoader().getResource("/main/resources/carcassonne_game.fxml")));
        
        Screen screen = Screen.getPrimary();

        primaryStage.setScene(scene);
       // primaryStage.setFullScreen(true);
        primaryStage.show(); 
    }
    
    public static void main(String[] args) {
        launch(args);
    }
}
